local OfferType = {
	COINS = 1,
	ITEM = 2,
	BACKPACK = 3,
	OUTFIT = 4,
	MOUNT = 5,
	HOUSE = 6,
}

local boxes = {
	[ITEM_REVOADA_JADE_BOX] = { -- revoada jade box
		{
			type = OfferType.COINS,
			id = 22118,
			count = 500,
		}, -- coins
		{
			type = OfferType.ITEM,
			id = ITEM_MEGA_ROULETTE,
			count = 1,
		}, -- mega roulette
		{
			type = OfferType.ITEM,
			id = ITEM_MAGIC_WALL_CUSTOM,
			count = 1,
		}, -- magic wall custom
		{
			type = OfferType.HOUSE,
			id = 64018,
			count = 1,
		}, -- sanguinary exercise dummy
	},
	[ITEM_REVOADA_TURQUOISE_BOX] = { -- revoada turquoise box
		{
			type = OfferType.COINS,
			id = 22118,
			count = 1000,
		}, -- coins
		{
			type = OfferType.ITEM,
			id = ITEM_MEGA_ROULETTE,
			count = 2,
		}, -- mega roulette
		{
			type = OfferType.MOUNT,
			id = 271,
			count = 1,
			valueCoins = 100,
		}, -- revodraptor
		{
			type = OfferType.ITEM,
			id = ITEM_MAGIC_WALL_CUSTOM,
			count = 1,
		}, -- magic wall custom
		{
			type = OfferType.HOUSE,
			id = 64018,
			count = 1,
		}, -- sanguinary exercise dummy
		{
			type = OfferType.BACKPACK,
			id = 64052,
			count = 1,
		}, -- pikachu backpack
	},
	[ITEM_REVOADA_RUBY_BOX] = { -- revoada ruby box
		{
			type = OfferType.COINS,
			id = 22118,
			count = 1500,
		}, -- coins
		{
			type = OfferType.ITEM,
			id = ITEM_MEGA_ROULETTE,
			count = 3,
		}, -- mega roulette
		{
			type = OfferType.OUTFIT,
			id = { female = 3003, male = 3002 },
			count = 1,
			valueCoins = 100,
		}, -- skull revoada outfit
		{
			type = OfferType.MOUNT,
			id = 223,
			count = 1,
			valueCoins = 100,
		}, -- gorgon hydra
		{
			type = OfferType.ITEM,
			id = ITEM_MAGIC_WALL_CUSTOM,
			count = 2,
		}, -- magic wall custom
		{
			type = OfferType.HOUSE,
			id = 64018,
			count = 1,
		}, -- sanguinary exercise dummy
		{
			type = OfferType.HOUSE,
			id = ITEM_GODNESS_FORGE,
			count = 1,
		}, -- godness forge
		{
			type = OfferType.BACKPACK,
			id = 64039,
			count = 1,
		}, -- majinboo backpack
	},
}

function createHistory(accId, message, value)
	GameStore.insertHistory(accId, GameStore.HistoryTypes.HISTORY_TYPE_NONE, message, value, GameStore.CoinType.Transferable)
end

local customBox = Action()
function customBox.onUse(player, box, fromPosition, target, toPosition, isHotkey)
	local boxItems = boxes[box.itemid]
	if not boxItems then
		return false
	end

	local boxName = ItemType(box.itemid):getName():lower()
	box:remove(1)

	local itemsCreated = {}
	for _, item in ipairs(boxItems) do
		local count = item.count or 1
		if item.type == OfferType.COINS then
			player:addTransferableCoins(count)
			createHistory(player:getAccountId(), boxName .. " gift", count)
			table.insert(itemsCreated, string.format("%d transferable tibia coins.", count))
		elseif item.type == OfferType.ITEM or item.type == OfferType.BACKPACK or item.type == OfferType.HOUSE then
			local itemType = ItemType(item.id)
			if itemType then
				local inbox = player:getStoreInbox()
				if inbox then
					if item.type == OfferType.HOUSE then
						local decoKit = inbox:addItem(ITEM_DECORATION_KIT, 1)
						if decoKit then
							decoKit:setAttribute(ITEM_ATTRIBUTE_DESCRIPTION, "Unwrap it in your own house to create a <" .. itemType:getName() .. ">.")
							decoKit:setCustomAttribute("unWrapId", item.id)
							decoKit:setAttribute(ITEM_ATTRIBUTE_STORE, systemTime())
							player:sendUpdateContainer(inbox)
							table.insert(itemsCreated, string.format("%d %s in your store inbox.", count, itemType:getName()))
						end
					else
						local pendingCount = 0
						while pendingCount < count do
							local newItem = inbox:addItem(item.id, 1)
							if item.type == OfferType.ITEM then
								newItem:setAttribute(ITEM_ATTRIBUTE_STORE, systemTime())
							end
							pendingCount = pendingCount + 1
						end
						table.insert(itemsCreated, string.format("%d %s in your store inbox.", count, itemType:getName()))
					end
				end
			end
		else
			if item.type == OfferType.OUTFIT then
				local female, male = item.id.female, item.id.male
				if player:hasOutfit(female) or player:hasOutfit(male) then
					player:addTransferableCoins(item.valueCoins)
					createHistory(player:getAccountId(), boxName .. " gift, because you already have full skull revoada outfit", item.valueCoins)
					table.insert(itemsCreated, string.format("%d transferable tibia coins, because you already have this outfit.", item.valueCoins))
				else
					player:addOutfitAddon(female, 3)
					player:addOutfitAddon(male, 3)
					table.insert(itemsCreated, "Full Skull Revoada outfit.")
				end
			elseif item.type == OfferType.MOUNT then
				local mountName = item.id == 223 and "Gorgon Hydra" or "Revodraptor"
				if player:hasMount(item.id) then
					player:addTransferableCoins(item.valueCoins)
					createHistory(player:getAccountId(), string.format("%s gift, because you already have %s mount", boxName, mountName), item.valueCoins)
					table.insert(itemsCreated, string.format("%d transferable tibia coins, because you already have this mount.", item.valueCoins))
				else
					player:addMount(item.id)
					table.insert(itemsCreated, string.format("1 %s mount.", mountName))
				end
			end
		end
	end

	player:sendTextMessage(MESSAGE_EVENT_ADVANCE, string.format("Congratulations! \zYou have used %s and won the followed items:\n%s", boxName, table.concat(itemsCreated, "\n")))
	player:getPosition():sendMagicEffect(CONST_ME_GIFT_WRAPS)

	return true
end

customBox:id(ITEM_REVOADA_RUBY_BOX, ITEM_REVOADA_JADE_BOX, ITEM_REVOADA_TURQUOISE_BOX)
customBox:register()
