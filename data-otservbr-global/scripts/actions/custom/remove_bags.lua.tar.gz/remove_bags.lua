local removeBags = Action()

local removeBagId = ITEM_REMOVE_BAGS

function removeBags.onUse(player, item, fromPosition, target, toPosition, isHotkey)
	if target.itemid == removeBagId and item.uid == 38882 then
		local playerDelay = {}
		local playerId = player:getId()
		if not playerDelay[playerId] then
			playerDelay[playerId] = true

			local shoppingBagsToRemove = {}
			for _, bpItem in ipairs(player:getSlotItem(CONST_SLOT_BACKPACK):getItems(true)) do
				if bpItem:getId() == ITEM_SHOPPING_BAG and bpItem:getEmptySlots() == 20 then
					table.insert(shoppingBagsToRemove, bpItem)
				end
			end

			local emptyParcelsToRemove = {}
			for _, inboxItem in ipairs(player:getStoreInbox():getItems(true)) do
				if inboxItem:getId() == ITEM_PARCEL_STAMPED and inboxItem:getEmptySlots() == 10 then
					table.insert(emptyParcelsToRemove, inboxItem)
				end
			end

			if #shoppingBagsToRemove > 0 then
				for _, bag in pairs(shoppingBagsToRemove) do
					bag:remove()
				end
				player:sendTextMessage(MESSAGE_EVENT_ADVANCE, #emptyParcelsToRemove .. " empty parcels were removed from your store inbox!")
			end

			if #emptyParcelsToRemove > 0 then
				for _, parcel in pairs(emptyParcelsToRemove) do
					parcel:remove()
				end
			end

			if #shoppingBagsToRemove + #emptyParcelsToRemove > 0 then
				player:sendTextMessage(MESSAGE_EVENT_ADVANCE, string.format("You cleaned your %d empty shopping bags in your main backpack%s.", #shoppingBagsToRemove, #emptyParcelsToRemove > 0 and " and removed " .. #emptyParcelsToRemove .. " empty parcels from your store inbox" or ""))
			else
				player:sendTextMessage(MESSAGE_FAILURE, "You don't have shopping bags in your main backpack!")
			end

			addEvent(function(pid)
				playerDelay[pid] = false
			end, 2000, playerId)
		end
	end
	return true
end

removeBags:id(removeBagId)
removeBags:register()
