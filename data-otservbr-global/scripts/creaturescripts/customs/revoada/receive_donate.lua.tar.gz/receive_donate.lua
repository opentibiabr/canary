local checkHasDonationPending = CreatureEvent("checkHasDonationPending")

function checkHasDonationPending.onLogin(player)
	local resultId = db.storeQuery("SELECT `id`, `code` FROM `pagseguro_transactions_old` WHERE `payment_status` <> 'CANCELLED' AND `payment_status` <> 'REFUNDED' AND `delivered` = '1' AND `account_id` = " .. player:getAccountId() .. ";")
	if not resultId then
		return true
	end

	local idsToUpdate = {}
	local codeSum = 0
	repeat
		table.insert(idsToUpdate, Result.getNumber(resultId, "id"))
		codeSum = codeSum + Result.getNumber(resultId, "code")
	until not Result.next(resultId)
	Result.free(resultId)

	if #idsToUpdate > 0 and codeSum > 0 then
		for _, id in pairs(idsToUpdate) do
			db.query("UPDATE `pagseguro_transactions_old` SET `payment_status` = 'REFUNDED', `delivered` = '2' WHERE `id` = " .. id .. ";")
		end

		local valueToRefund = codeSum / 0.05
		player:addTransferableCoins(valueToRefund)
		GameStore.insertHistory(player:getAccountId(), GameStore.HistoryTypes.HISTORY_TYPE_NONE, "Refunded Donates", valueToRefund, GameStore.CoinType.Transferable)

		player:sendTextMessage(MESSAGE_EVENT_ADVANCE, string.format("Congratulations! \zYou have received a total of %d transferable tibia coins.", valueToRefund))
		player:getPosition():sendMagicEffect(CONST_ME_HOLYAREA)

		logger.info("Player {} was refunded with {} transferable tibia coins.", player:getName(), valueToRefund)
	end

	return true
end

if os.time() < 1720062001 then
	-- 04/07
	checkHasDonationPending:register()
end
