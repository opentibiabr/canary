local config = {
	damageDay = {
		min = 0.70,
		max = 0.75,
	},
	damageNight = {
		min = 0.95,
		max = 1,
	},
	hourStartDay = 6,
	hourEndDay = 18,
}

local combat = Combat()
combat:setParameter(COMBAT_PARAM_TYPE, COMBAT_DEATHDAMAGE)
combat:setParameter(COMBAT_PARAM_EFFECT, CONST_ME_MORTAREA)
combat:setParameter(COMBAT_PARAM_DISTANCEEFFECT, CONST_ANI_SUDDENDEATH)

function onGetFormulaValues(player, level, maglevel)
	local min, max = ((level / 5) + (maglevel * 4.605)), ((level / 5) + (maglevel * 7.395))
	local hour = tonumber(os.date("%H", os.time())) -- Obtém a hora atual

	-- Define o valor do dano com base na hora do dia
	if hour >= config.hourStartDay and hour < config.hourEndDay then -- Dia
		min = min * config.damageDay.min
		max = max * config.damageDay.max
	else -- Noite
		min = min * config.damageNight.min
		max = max * config.damageNight.max
	end

	return -min, -max
end

combat:setCallback(CALLBACK_PARAM_LEVELMAGICVALUE, "onGetFormulaValues")

local rune = Spell("rune")

function rune.onCastSpell(creature, var, isHotkey)
	return combat:execute(creature, var)
end

rune:group("attack")
rune:name("sudden death rune")
rune:runeId(3155)
rune:allowFarUse(true)
rune:charges(3)
rune:level(45)
rune:magicLevel(15)
rune:cooldown(2 * 1000)
rune:groupCooldown(2 * 1000)
rune:needTarget(true)
rune:isBlocking(true) -- True = Solid / False = Creature
--rune:register()
